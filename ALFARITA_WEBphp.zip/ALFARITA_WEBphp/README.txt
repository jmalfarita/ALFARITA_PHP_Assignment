ALFARITA PHP ASSIGNMENT - QUICK START

1. Copy the ALFARITA_PHP_Assignment folder into your XAMPP htdocs folder.
   Example: C:\xampp\htdocs\ALFARITA_PHP_Assignment\
   If XAMPP is on D:, use D:\xampp\htdocs\ALFARITA_PHP_Assignment\
2. Start Apache in XAMPP Control Panel.
3. Open http://localhost/ALFARITA_PHP_Assignment/alfarita_login/register.php
4. Register, then log in. Successful login opens the landing page. Logout ends the session.
5. Screenshot the code and output for the assignment, then upload the PHP files to GitHub.

Assignment concepts demonstrated:
- index.php uses include for header, navbar, main-content, and footer.
- register.php and login.php process POST forms in PHP.
- preg_match regular expressions validate username, email, and password.
- password_hash/password_verify are used for password handling.
- session stores the demo account for this local exercise; restarting the session/browser may require registering again.

NOTE: This is a classroom demo, not production authentication. Do not upload real credentials. GitHub Pages does not execute PHP; test locally with XAMPP.
